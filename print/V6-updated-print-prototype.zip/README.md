# V6 updated print prototype

Open `cad/v6-updated-print/RibosomeV6UpdatedPrint.FCStd` in FreeCAD.
Its adjacent macro provides optional controls. The native motion also works
without the Python sources. Earlier models in the full repository are preserved.

Open `fit-plate/V6-updated-PETG-fit-trials.3mf` in Bambu Studio for the nine
PETG fastening/spring-fit test pieces. It uses A1 mini / 0.4 mm and Bambu PETG
Translucent, 0.12 mm layers. Studio estimates about 31 minutes and 2.1 g.
Review Preview before printing. No print has been sent.

`exports/` contains 14 grouped model parts and six fit coupons as STEP/STL,
with quantities/materials in export-report.json and independent mesh checks.
RNA remains the existing nominal-layout CAD reference; a new flat RNA pattern
is not included. Existing bead bores and the copper-wire geometry are unchanged.
This is not a complete sliced toy or a physically qualified mechanism.

Buy one TECH-AR MS/095P TYP2 cap-return spring and one MS/095L TYP1 pawl-bias
spring; direct Allegro links and installation details are in
`print/v6-updated-a1-mini/README.md` and `cad/v6-updated-print/engineering.md`.
All screws, keyed nuts, the spindle cap and spring supports are printable.
The user supplies suitable copper wire from existing supplies.

The CAD evidence includes a complete sweep plus a focused material-removal
correction to the cup wall, with unchanged-geometry and root checks. Mechanical
status remains REVIEW. Printed fits, spring forces/preload, detent holding,
feeding and durability require physical trials. Start with the small fit plate.
Development commands in the guides refer to the full repository.
